//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import window_to_front

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  WindowToFrontPlugin.register(with: registry.registrar(forPlugin: "WindowToFrontPlugin"))
}
