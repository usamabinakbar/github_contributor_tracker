# window_to_front

Supports: Windows, Linux & MacOS

After the authentication flow or in any other usecases, when, you are left staring at a web browser page. Ideally, you should automatically return to the application. 

So to return automatically from the browser, and bring the application window to front this plugin is useful.