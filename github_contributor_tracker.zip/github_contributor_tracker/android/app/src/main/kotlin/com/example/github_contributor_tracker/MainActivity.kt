package com.example.github_contributor_tracker

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
