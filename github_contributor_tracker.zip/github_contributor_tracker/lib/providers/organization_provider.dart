import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:github_contributor_tracker/models/organization.dart';
import 'package:github_contributor_tracker/utils/constants.dart';

class OrganizationProvider with ChangeNotifier {
  List<Organization> _recentOrganizations = [];
  Organization? _currentOrganization;
  bool _isLoading = false;
  
  List<Organization> get recentOrganizations => _recentOrganizations;
  Organization? get currentOrganization => _currentOrganization;
  bool get isLoading => _isLoading;
  
  OrganizationProvider() {
    _loadRecentOrganizations();
  }
  
  Future<void> _loadRecentOrganizations() async {
    _isLoading = true;
    notifyListeners();
    
    try {
      final prefs = await SharedPreferences.getInstance();
      final orgsJson = prefs.getString(AppConstants.recentOrgsKey);
      
      if (orgsJson != null) {
        final List<dynamic> decoded = jsonDecode(orgsJson);
        _recentOrganizations = decoded
            .map((item) => Organization.fromJson(item))
            .toList();
      }
    } catch (e) {
      print('Error loading recent organizations: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }
  
  Future<void> _saveRecentOrganizations() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final orgsJson = jsonEncode(_recentOrganizations.map((org) => org.toJson()).toList());
      await prefs.setString(AppConstants.recentOrgsKey, orgsJson);
    } catch (e) {
      print('Error saving recent organizations: $e');
    }
  }
  
  void setCurrentOrganization(Organization organization) {
    _currentOrganization = organization;
    _addToRecentOrganizations(organization);
    notifyListeners();
  }
  
  void _addToRecentOrganizations(Organization organization) {
    // Remove if already exists
    _recentOrganizations.removeWhere((org) => org.login == organization.login);
    
    // Add to the beginning
    _recentOrganizations.insert(0, organization);
    
    // Limit to 5 recent organizations
    if (_recentOrganizations.length > 5) {
      _recentOrganizations = _recentOrganizations.sublist(0, 5);
    }
    
    // Save to preferences
    _saveRecentOrganizations();
  }
  
  void clearRecentOrganizations() {
    _recentOrganizations.clear();
    _saveRecentOrganizations();
    notifyListeners();
  }
}