import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:oauth2_client/oauth2_client.dart';
import 'package:oauth2_client/oauth2_helper.dart';
import 'package:github_contributor_tracker/models/github_user.dart';
import 'package:github_contributor_tracker/utils/constants.dart';

class AuthProvider with ChangeNotifier {
  final FlutterSecureStorage _secureStorage = const FlutterSecureStorage();
  final OAuth2Client _oauth2Client = OAuth2Client(
    authorizeUrl: AppConstants.githubAuthUrl,
    tokenUrl: AppConstants.githubTokenUrl,
    redirectUri: AppConstants.redirectUrl,
    customUriScheme: 'githubtrackerapp',
  );
  
  late OAuth2Helper _oauth2Helper;
  
  GitHubUser? _currentUser;
  String? _token;
  bool _isLoading = false;
  
  GitHubUser? get currentUser => _currentUser;
  String? get token => _token;
  bool get isLoading => _isLoading;
  bool get isAuthenticated => _token != null;
  
  AuthProvider() {
    _oauth2Helper = OAuth2Helper(
      _oauth2Client,
      grantType: OAuth2Helper.authorizationCode,
      clientId: AppConstants.clientId,
      clientSecret: AppConstants.clientSecret,
      scopes: AppConstants.scopes,
    );
    
    // Initialize - load saved token and user
    _loadSavedAuth();
  }
  
  Future<void> _loadSavedAuth() async {
    _isLoading = true;
    notifyListeners();
    
    try {
      // Load token
      _token = await _secureStorage.read(key: AppConstants.tokenKey);
      
      // Load user if token exists
      if (_token != null) {
        final userJson = await _secureStorage.read(key: AppConstants.userKey);
        if (userJson != null) {
          _currentUser = GitHubUser.fromJson(jsonDecode(userJson));
        } else {
          // Fetch user info if we have token but no saved user data
          await _fetchUserInfo();
        }
      }
    } catch (e) {
      print('Error loading saved auth: $e');
      _token = null;
      _currentUser = null;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }
  
  Future<bool> login() async {
    _isLoading = true;
    notifyListeners();
    
    try {
      // Request token via OAuth
      final tokenResponse = await _oauth2Helper.getToken();
      _token = tokenResponse?.accessToken;
      
      if (_token != null) {
        // Save token
        await _secureStorage.write(key: AppConstants.tokenKey, value: _token);
        
        // Fetch and save user info
        await _fetchUserInfo();
        
        return true;
      }
      return false;
    } catch (e) {
      print('Login error: $e');
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }
  
  Future<void> _fetchUserInfo() async {
    if (_token == null) return;
    
    try {
      final response = await http.get(
        Uri.parse('${AppConstants.githubApiBaseUrl}/user'),
        headers: {
          'Accept': 'application/vnd.github.v3+json',
          'Authorization': 'token $_token',
        },
      );
      
      if (response.statusCode == 200) {
        final userData = jsonDecode(response.body);
        _currentUser = GitHubUser.fromJson(userData);
        
        // Save user data
        await _secureStorage.write(
          key: AppConstants.userKey,
          value: jsonEncode(_currentUser!.toJson()),
        );
      } else {
        throw Exception('Failed to fetch user info: ${response.statusCode}');
      }
    } catch (e) {
      print('Error fetching user info: $e');
    }
  }
  
  Future<void> logout() async {
    _isLoading = true;
    notifyListeners();
    
    try {
      // Clear saved data
      await _secureStorage.delete(key: AppConstants.tokenKey);
      await _secureStorage.delete(key: AppConstants.userKey);
      
      // Clear in-memory data
      _token = null;
      _currentUser = null;
    } catch (e) {
      print('Logout error: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }
}