class AppConstants {
  // GitHub API URLs
  static const String githubApiBaseUrl = 'https://api.github.com';
  static const String githubAuthUrl = 'https://github.com/login/oauth/authorize';
  static const String githubTokenUrl = 'https://github.com/login/oauth/access_token';
  
  // OAuth Settings - Replace with your actual client ID and secret
  static const String clientId = 'your_github_client_id';
  static const String clientSecret = 'your_github_client_secret';
  static const String redirectUrl = 'githubtrackerapp://callback';
  static const List<String> scopes = ['repo', 'read:org', 'read:user'];
  
  // Storage Keys
  static const String tokenKey = 'github_token';
  static const String userKey = 'github_user';
  static const String recentOrgsKey = 'recent_organizations';
  
  // Rate Limiting
  static const int defaultPageSize = 100;
  static const int maxItemsToFetch = 1000;
}