class Repository {
  final int id;
  final String name;
  final String fullName;
  final String? description;
  final bool isPrivate;
  final bool isFork;
  final String htmlUrl;
  final String? language;
  final int stargazersCount;
  final int forksCount;
  final int openIssuesCount;
  
  Repository({
    required this.id,
    required this.name,
    required this.fullName,
    this.description,
    required this.isPrivate,
    required this.isFork,
    required this.htmlUrl,
    this.language,
    required this.stargazersCount,
    required this.forksCount,
    required this.openIssuesCount,
  });
  
  factory Repository.fromJson(Map<String, dynamic> json) {
    return Repository(
      id: json['id'] ?? 0,
      name: json['name'] ?? '',
      fullName: json['full_name'] ?? '',
      description: json['description'],
      isPrivate: json['private'] ?? false,
      isFork: json['fork'] ?? false,
      htmlUrl: json['html_url'] ?? '',
      language: json['language'],
      stargazersCount: json['stargazers_count'] ?? 0,
      forksCount: json['forks_count'] ?? 0,
      openIssuesCount: json['open_issues_count'] ?? 0,
    );
  }
}