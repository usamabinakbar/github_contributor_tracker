class CommitStatistics {
  final String authorLogin;
  final int total;
  final List<WeeklyCommit> weeks;
  
  CommitStatistics({
    required this.authorLogin,
    required this.total,
    required this.weeks,
  });
  
  factory CommitStatistics.fromJson(Map<String, dynamic> json) {
    final List<dynamic> weeksJson = json['weeks'] ?? [];
    
    return CommitStatistics(
      authorLogin: json['author']?['login'] ?? '',
      total: json['total'] ?? 0,
      weeks: weeksJson.map((week) => WeeklyCommit.fromJson(week)).toList(),
    );
  }
}

class WeeklyCommit {
  final int week; // Unix timestamp for the start of the week
  final int additions;
  final int deletions;
  final int commits;
  
  WeeklyCommit({
    required this.week,
    required this.additions,
    required this.deletions,
    required this.commits,
  });
  
  factory WeeklyCommit.fromJson(Map<String, dynamic> json) {
    return WeeklyCommit(
      week: json['w'] ?? 0,
      additions: json['a'] ?? 0,
      deletions: json['d'] ?? 0,
      commits: json['c'] ?? 0,
    );
  }
}