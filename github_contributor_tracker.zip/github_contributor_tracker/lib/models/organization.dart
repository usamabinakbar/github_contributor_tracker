class Organization {
  final String login;
  final int id;
  final String avatarUrl;
  final String? name;
  final String? description;
  final int publicRepos;
  
  Organization({
    required this.login,
    required this.id,
    required this.avatarUrl,
    this.name,
    this.description,
    required this.publicRepos,
  });
  
  factory Organization.fromJson(Map<String, dynamic> json) {
    return Organization(
      login: json['login'] ?? '',
      id: json['id'] ?? 0,
      avatarUrl: json['avatar_url'] ?? '',
      name: json['name'],
      description: json['description'],
      publicRepos: json['public_repos'] ?? 0,
    );
  }
  
  Map<String, dynamic> toJson() {
    return {
      'login': login,
      'id': id,
      'avatar_url': avatarUrl,
      'name': name,
      'description': description,
      'public_repos': publicRepos,
    };
  }
}