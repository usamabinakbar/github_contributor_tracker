class Contributor {
  final String login;
  final int id;
  final String avatarUrl;
  final int contributions;
  final String? name;
  
  Contributor({
    required this.login,
    required this.id,
    required this.avatarUrl,
    required this.contributions,
    this.name,
  });
  
  factory Contributor.fromJson(Map<String, dynamic> json) {
    return Contributor(
      login: json['login'] ?? '',
      id: json['id'] ?? 0,
      avatarUrl: json['avatar_url'] ?? '',
      contributions: json['contributions'] ?? 0,
      name: json['name'],
    );
  }
}