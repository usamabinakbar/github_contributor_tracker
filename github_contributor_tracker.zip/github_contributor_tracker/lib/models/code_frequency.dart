class CodeFrequency {
  final int week; // Unix timestamp for the start of the week
  final int additions;
  final int deletions;
  
  CodeFrequency({
    required this.week,
    required this.additions,
    required this.deletions,
  });
  
  factory CodeFrequency.fromJson(List<dynamic> json) {
    return CodeFrequency(
      week: json[0] ?? 0,
      additions: json[1] ?? 0,
      deletions: json[2] != null ? -(json[2] as int) : 0, // Deletions are negative in API
    );
  }
}