class CommitActivity {
  final int total;
  final int week; // Unix timestamp
  final List<int> days; // Commits per day of the week
  
  CommitActivity({
    required this.total,
    required this.week,
    required this.days,
  });
  
  factory CommitActivity.fromJson(Map<String, dynamic> json) {
    final List<dynamic> daysJson = json['days'] ?? [];
    
    return CommitActivity(
      total: json['total'] ?? 0,
      week: json['week'] ?? 0,
      days: daysJson.map((day) => day as int).toList(),
    );
  }
}