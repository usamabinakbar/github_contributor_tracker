import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:github_contributor_tracker/providers/auth_provider.dart';
import 'package:github_contributor_tracker/providers/organization_provider.dart';
import 'package:github_contributor_tracker/models/organization.dart';
import 'package:github_contributor_tracker/screens/dashboard_screen.dart';
import 'package:github_contributor_tracker/screens/login_screen.dart';
import 'package:github_contributor_tracker/screens/settings_screen.dart';
import 'package:github_contributor_tracker/services/github_api_service.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController _searchController = TextEditingController();
  bool _isLoading = false;
  List<Organization> _userOrganizations = [];
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _loadUserOrganizations();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadUserOrganizations() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final authProvider = Provider.of<AuthProvider>(context, listen: false);
      if (authProvider.token == null) {
        throw Exception('Not authenticated');
      }

      final apiService = GitHubApiService(authProvider.token!);
      _userOrganizations = await apiService.getUserOrganizations();
    } catch (e) {
      setState(() {
        _errorMessage = 'Failed to load organizations: ${e.toString()}';
      });
      print('Error loading organizations: $e');
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _searchOrganization() async {
    final orgName = _searchController.text.trim();
    if (orgName.isEmpty) return;

    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final authProvider = Provider.of<AuthProvider>(context, listen: false);
      if (authProvider.token == null) {
        throw Exception('Not authenticated');
      }

      final apiService = GitHubApiService(authProvider.token!);
      final organization = await apiService.getOrganization(orgName);

      // Save to recent orgs
      final orgProvider = Provider.of<OrganizationProvider>(context, listen: false);
      orgProvider.setCurrentOrganization(organization);

      // Navigate to dashboard
      if (mounted) {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => DashboardScreen(organization: organization),
          ),
        );
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'Organization not found or inaccessible';
      });
      print('Error searching organization: $e');
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _logout() async {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    await authProvider.logout();

    if (mounted) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const LoginScreen()),
      );
    }
  }

  void _openSettings() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const SettingsScreen(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final authProvider = Provider.of<AuthProvider>(context);
    final orgProvider = Provider.of<OrganizationProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('GitHub Contributor Tracker'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: _openSettings,
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: _logout,
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // User info
            if (authProvider.currentUser != null)
              Card(
                margin: const EdgeInsets.only(bottom: 16),
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundImage: NetworkImage(authProvider.currentUser!.avatarUrl),
                  ),
                  title: Text(
                    authProvider.currentUser!.name ?? authProvider.currentUser!.login,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  subtitle: Text('@${authProvider.currentUser!.login}'),
                ),
              ),

            // Search organization
            Card(
              elevation: 4,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Search Organization',
                      style: theme.textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _searchController,
                            decoration: const InputDecoration(
                              hintText: 'Enter organization name',
                              prefixIcon: Icon(Icons.search),
                              border: OutlineInputBorder(),
                            ),
                            onSubmitted: (_) => _searchOrganization(),
                          ),
                        ),
                        const SizedBox(width: 8),
                        ElevatedButton(
                          onPressed: _isLoading ? null : _searchOrganization,
                          child: _isLoading
                              ? const SizedBox(
                                  width: 20,
                                  height: 20,
                                  child: CircularProgressIndicator(
                                    color: Colors.white,
                                    strokeWidth: 2,
                                  ),
                                )
                              : const Text('Search'),
                        ),
                      ],
                    ),
                    if (_errorMessage != null)
                      Padding(
                        padding: const EdgeInsets.only(top: 8.0),
                        child: Text(
                          _errorMessage!,
                          style: TextStyle(color: theme.colorScheme.error),
                        ),
                      ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 24),

            // Your Organizations
            Text(
              'Your Organizations',
              style: theme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: _isLoading
                  ? const Center(child: CircularProgressIndicator())
                  : _userOrganizations.isEmpty
                      ? Center(
                          child: Text(
                            'No organizations found',
                            style: theme.textTheme.bodyLarge,
                          ),
                        )
                      : ListView.builder(
                          itemCount: _userOrganizations.length,
                          itemBuilder: (context, index) {
                            final org = _userOrganizations[index];
                            return Card(
                              margin: const EdgeInsets.only(bottom: 8),
                              child: ListTile(
                                leading: CircleAvatar(
                                  backgroundImage: NetworkImage(org.avatarUrl),
                                ),
                                title: Text(org.name ?? org.login),
                                subtitle: Text('${org.publicRepos} repositories'),
                                trailing: const Icon(Icons.chevron_right),
                                onTap: () {
                                  // Set current organization and navigate to dashboard
                                  orgProvider.setCurrentOrganization(org);
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => DashboardScreen(organization: org),
                                    ),
                                  );
                                },
                              ),
                            );
                          },
                        ),
            ),

            const SizedBox(height: 16),

            // Recent Organizations
            if (orgProvider.recentOrganizations.isNotEmpty) ...[
              Text(
                'Recent Organizations',
                style: theme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              SizedBox(
                height: 120,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: orgProvider.recentOrganizations.length,
                  itemBuilder: (context, index) {
                    final org = orgProvider.recentOrganizations[index];
                    return GestureDetector(
                      onTap: () {
                        // Navigate to dashboard
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => DashboardScreen(organization: org),
                          ),
                        );
                      },
                      child: Container(
                        width: 120,
                        margin: const EdgeInsets.only(right: 8),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            CircleAvatar(
                              radius: 30,
                              backgroundImage: NetworkImage(org.avatarUrl),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              org.login,
                              style: const TextStyle(fontWeight: FontWeight.bold),
                              overflow: TextOverflow.ellipsis,
                            ),
                            Text('${org.publicRepos} repos'),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}