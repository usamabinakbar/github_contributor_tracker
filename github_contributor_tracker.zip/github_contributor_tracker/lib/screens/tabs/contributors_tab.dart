import 'package:flutter/material.dart';
import 'package:github_contributor_tracker/models/organization.dart';
import 'package:github_contributor_tracker/models/contributor.dart';
import 'package:github_contributor_tracker/services/github_api_service.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:percent_indicator/linear_percent_indicator.dart';

class ContributorsTab extends StatefulWidget {
  final Organization organization;
  final String token;

  const ContributorsTab({
    Key? key,
    required this.organization,
    required this.token,
  }) : super(key: key);

  @override
  ContributorsTabState createState() => ContributorsTabState();
}

class ContributorsTabState extends State<ContributorsTab> {
  late GitHubApiService _apiService;
  
  bool _isLoading = true;
  String? _errorMessage;
  List<Contributor> _contributors = [];
  String _searchQuery = '';
  
  @override
  void initState() {
    super.initState();
    _apiService = GitHubApiService(widget.token);
    _loadContributors();
  }
  
  Future<void> _loadContributors() async {
    if (!mounted) return;
    
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });
    
    try {
      final contributorsMap = await _apiService.getAllOrganizationContributors(
        widget.organization.login,
      );
      
      _contributors = contributorsMap.values.toList()
        ..sort((a, b) => b.contributions.compareTo(a.contributions));
      
    } catch (e) {
      setState(() {
        _errorMessage = 'Error loading contributors: ${e.toString()}';
      });
      print('Error loading contributors: $e');
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }
  
  List<Contributor> get filteredContributors {
    if (_searchQuery.isEmpty) {
      return _contributors;
    }
    
    final query = _searchQuery.toLowerCase();
    return _contributors.where((contributor) {
      return contributor.login.toLowerCase().contains(query) ||
             (contributor.name?.toLowerCase().contains(query) ?? false);
    }).toList();
  }
  
  void refreshData() {
    _loadContributors();
  }
  
  void _openGitHubProfile(String username) async {
    final url = 'https://github.com/$username';
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not open GitHub profile')),
        );
      }
    }
  }
  
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return Column(
      children: [
        // Search bar
        Padding(
          padding: const EdgeInsets.all(16),
          child: TextField(
            decoration: InputDecoration(
              hintText: 'Search contributors...',
              prefixIcon: const Icon(Icons.search),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            onChanged: (value) {
              setState(() {
                _searchQuery = value;
              });
            },
          ),
        ),
        
        // Contributors list
        Expanded(
          child: _isLoading
              ? const Center(child: CircularProgressIndicator())
              : _errorMessage != null
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.error_outline,
                            color: theme.colorScheme.error,
                            size: 48,
                          ),
                          const SizedBox(height: 16),
                          Text(
                            _errorMessage!,
                            style: theme.textTheme.titleMedium?.copyWith(
                              color: theme.colorScheme.error,
                            ),
                            textAlign: TextAlign.center,
                          ),
                          const SizedBox(height: 24),
                          ElevatedButton(
                            onPressed: refreshData,
                            child: const Text('Retry'),
                          ),
                        ],
                      ),
                    )
                  : filteredContributors.isEmpty
                      ? Center(
                          child: Text(
                            _searchQuery.isEmpty
                                ? 'No contributors found'
                                : 'No contributors match your search',
                            style: theme.textTheme.titleMedium,
                          ),
                        )
                      : _buildContributorsList(filteredContributors, theme),
        ),
      ],
    );
  }
  
  Widget _buildContributorsList(List<Contributor> contributors, ThemeData theme) {
    // Calculate the maximum contribution count for percentage calculation
    final maxContributions = contributors.isNotEmpty 
        ? contributors.first.contributions.toDouble() 
        : 1.0;
    
    return ListView.builder(
      padding: const EdgeInsets.all(8),
      itemCount: contributors.length,
      itemBuilder: (context, index) {
        final contributor = contributors[index];
        final contributionPercent = contributor.contributions / maxContributions;
        
        return Card(
          margin: const EdgeInsets.only(bottom: 8),
          child: InkWell(
            onTap: () => _openGitHubProfile(contributor.login),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      CircleAvatar(
                        backgroundImage: NetworkImage(contributor.avatarUrl),
                        radius: 24,
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              contributor.name ?? contributor.login,
                              style: theme.textTheme.titleMedium?.copyWith(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              '@${contributor.login}',
                              style: theme.textTheme.bodyMedium,
                            ),
                          ],
                        ),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            contributor.contributions.toString(),
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: theme.colorScheme.primary,
                              fontSize: 18,
                            ),
                          ),
                          const Text('commits'),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  LinearPercentIndicator(
                    animation: true,
                    lineHeight: 10.0,
                    animationDuration: 1000,
                    percent: contributionPercent,
                    linearStrokeCap: LinearStrokeCap.roundAll,
                    progressColor: theme.colorScheme.primary,
                    backgroundColor: theme.colorScheme.primary.withOpacity(0.1),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}