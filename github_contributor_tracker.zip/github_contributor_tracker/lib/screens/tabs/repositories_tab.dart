import 'package:flutter/material.dart';
import 'package:github_contributor_tracker/models/organization.dart';
import 'package:github_contributor_tracker/models/repository.dart';
import 'package:github_contributor_tracker/services/github_api_service.dart';
import 'package:url_launcher/url_launcher.dart';

class RepositoriesTab extends StatefulWidget {
  final Organization organization;
  final String token;

  const RepositoriesTab({
    Key? key,
    required this.organization,
    required this.token,
  }) : super(key: key);

  @override
  RepositoriesTabState createState() => RepositoriesTabState();
}

class RepositoriesTabState extends State<RepositoriesTab> {
  late GitHubApiService _apiService;
  
  bool _isLoading = true;
  String? _errorMessage;
  List<Repository> _repositories = [];
  String _searchQuery = '';
  String _sortBy = 'stars'; // Options: stars, forks, issues, updated
  
  @override
  void initState() {
    super.initState();
    _apiService = GitHubApiService(widget.token);
    _loadRepositories();
  }
  
  Future<void> _loadRepositories() async {
    if (!mounted) return;
    
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });
    
    try {
      _repositories = await _apiService.getOrganizationRepositories(
        widget.organization.login,
      );
      
      // Sort repositories based on the selected criteria
      _sortRepositories();
      
    } catch (e) {
      setState(() {
        _errorMessage = 'Error loading repositories: ${e.toString()}';
      });
      print('Error loading repositories: $e');
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }
  
  void _sortRepositories() {
    switch (_sortBy) {
      case 'stars':
        _repositories.sort((a, b) => b.stargazersCount.compareTo(a.stargazersCount));
        break;
      case 'forks':
        _repositories.sort((a, b) => b.forksCount.compareTo(a.forksCount));
        break;
      case 'issues':
        _repositories.sort((a, b) => b.openIssuesCount.compareTo(a.openIssuesCount));
        break;
      case 'name':
        _repositories.sort((a, b) => a.name.compareTo(b.name));
        break;
    }
  }
  
  List<Repository> get filteredRepositories {
    if (_searchQuery.isEmpty) {
      return _repositories;
    }
    
    final query = _searchQuery.toLowerCase();
    return _repositories.where((repo) {
      return repo.name.toLowerCase().contains(query) ||
             (repo.description?.toLowerCase().contains(query) ?? false);
    }).toList();
  }
  
  void refreshData() {
    _loadRepositories();
  }
  
  void _openRepositoryUrl(String url) async {
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not open repository URL')),
        );
      }
    }
  }
  
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return Column(
      children: [
        // Search and filter bar
        Container(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              TextField(
                decoration: InputDecoration(
                  hintText: 'Search repositories...',
                  prefixIcon: const Icon(Icons.search),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                onChanged: (value) {
                  setState(() {
                    _searchQuery = value;
                  });
                },
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  const Text('Sort by:'),
                  const SizedBox(width: 8),
                  DropdownButton<String>(
                    value: _sortBy,
                    onChanged: (value) {
                      if (value != null) {
                        setState(() {
                          _sortBy = value;
                          _sortRepositories();
                        });
                      }
                    },
                    items: const [
                      DropdownMenuItem(value: 'stars', child: Text('Stars')),
                      DropdownMenuItem(value: 'forks', child: Text('Forks')),
                      DropdownMenuItem(value: 'issues', child: Text('Issues')),
                      DropdownMenuItem(value: 'name', child: Text('Name')),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
        
        // Repository list
        Expanded(
          child: _isLoading
              ? const Center(child: CircularProgressIndicator())
              : _errorMessage != null
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.error_outline,
                            color: theme.colorScheme.error,
                            size: 48,
                          ),
                          const SizedBox(height: 16),
                          Text(
                            _errorMessage!,
                            style: theme.textTheme.titleMedium?.copyWith(
                              color: theme.colorScheme.error,
                            ),
                            textAlign: TextAlign.center,
                          ),
                          const SizedBox(height: 24),
                          ElevatedButton(
                            onPressed: refreshData,
                            child: const Text('Retry'),
                          ),
                        ],
                      ),
                    )
                  : filteredRepositories.isEmpty
                      ? Center(
                          child: Text(
                            _searchQuery.isEmpty
                                ? 'No repositories found'
                                : 'No repositories match your search',
                            style: theme.textTheme.titleMedium,
                          ),
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.all(8),
                          itemCount: filteredRepositories.length,
                          itemBuilder: (context, index) {
                            final repo = filteredRepositories[index];
                            return Card(
                              margin: const EdgeInsets.only(bottom: 8),
                              child: InkWell(
                                onTap: () => _openRepositoryUrl(repo.htmlUrl),
                                child: Padding(
                                  padding: const EdgeInsets.all(16.0),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Expanded(
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  repo.name,
                                                  style: theme.textTheme.titleLarge?.copyWith(
                                                    fontWeight: FontWeight.bold,
                                                  ),
                                                ),
                                                if (repo.description != null)
                                                  Padding(
                                                    padding: const EdgeInsets.only(top: 8.0),
                                                    child: Text(
                                                      repo.description!,
                                                      style: theme.textTheme.bodyMedium,
                                                      maxLines: 2,
                                                      overflow: TextOverflow.ellipsis,
                                                    ),
                                                  ),
                                              ],
                                            ),
                                          ),
                                          if (repo.language != null)
                                            Container(
                                              padding: const EdgeInsets.symmetric(
                                                horizontal: 8,
                                                vertical: 4,
                                              ),
                                              decoration: BoxDecoration(
                                                color: theme.colorScheme.primary.withOpacity(0.1),
                                                borderRadius: BorderRadius.circular(16),
                                              ),
                                              child: Text(
                                                repo.language!,
                                                style: TextStyle(
                                                  color: theme.colorScheme.primary,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                            ),
                                        ],
                                      ),
                                      const SizedBox(height: 16),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                                        children: [
                                          _buildStatItem(
                                            context, 
                                            Icons.star_border, 
                                            repo.stargazersCount.toString(), 
                                            'Stars'
                                          ),
                                          _buildStatItem(
                                            context, 
                                            Icons.fork_right, 
                                            repo.forksCount.toString(), 
                                            'Forks'
                                          ),
                                          _buildStatItem(
                                            context, 
                                            Icons.error_outline, 
                                            repo.openIssuesCount.toString(), 
                                            'Issues'
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
        ),
      ],
    );
  }
  
  Widget _buildStatItem(BuildContext context, IconData icon, String value, String label) {
    return Column(
      children: [
        Row(
          children: [
            Icon(icon, size: 16),
            const SizedBox(width: 4),
            Text(
              value,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          ],
        ),
        Text(
          label,
          style: Theme.of(context).textTheme.bodySmall,
        ),
      ],
    );
  }
}