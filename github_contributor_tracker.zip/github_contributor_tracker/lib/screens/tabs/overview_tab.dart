import 'package:flutter/material.dart';
import 'package:github_contributor_tracker/models/organization.dart';
import 'package:github_contributor_tracker/models/repository.dart';
import 'package:github_contributor_tracker/models/contributor.dart';
import 'package:github_contributor_tracker/models/commit_activity.dart';
import 'package:github_contributor_tracker/services/github_api_service.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:intl/intl.dart';

class OverviewTab extends StatefulWidget {
  final Organization organization;
  final String token;

  const OverviewTab({
    Key? key,
    required this.organization,
    required this.token,
  }) : super(key: key);

  @override
  OverviewTabState createState() => OverviewTabState();
}

class OverviewTabState extends State<OverviewTab> {
  late GitHubApiService _apiService;
  
  bool _isLoading = true;
  String? _errorMessage;
  
  // Data
  List<Repository> _repositories = [];
  List<Contributor> _topContributors = [];
  List<CommitActivity> _commitActivity = [];
  
  // Stats
  int _totalCommits = 0;
  int _totalPullRequests = 0;
  
  @override
  void initState() {
    super.initState();
    _apiService = GitHubApiService(widget.token);
    _loadData();
  }
  
  Future<void> _loadData() async {
    if (!mounted) return;
    
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });
    
    try {
      // Load repositories
      _repositories = await _apiService.getOrganizationRepositories(
        widget.organization.login,
      );
      
      // If there are repositories, get data for the first one as a sample
      if (_repositories.isNotEmpty) {
        // Get commit activity for main repository
        _commitActivity = await _apiService.getCommitActivity(
          widget.organization.login,
          _repositories[0].name,
        );
        
        // Calculate total commits from commit activity
        _totalCommits = _commitActivity.fold(0, (sum, week) => sum + week.total);
        
        // Placeholder for pull requests - you'd calculate this from actual data
        _totalPullRequests = _totalCommits ~/ 5; // Just an approximation
      }
      
      // Get top contributors across all repositories
      final contributorsMap = await _apiService.getAllOrganizationContributors(
        widget.organization.login,
      );
      
      _topContributors = contributorsMap.values.toList()
        ..sort((a, b) => b.contributions.compareTo(a.contributions));
      
    } catch (e) {
      setState(() {
        _errorMessage = 'Error loading data: ${e.toString()}';
      });
      print('Error loading overview data: $e');
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }
  
  void refreshData() {
    _loadData();
  }
  
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }
    
    if (_errorMessage != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.error_outline,
                color: theme.colorScheme.error,
                size: 48,
              ),
              const SizedBox(height: 16),
              Text(
                _errorMessage!,
                style: theme.textTheme.titleMedium?.copyWith(
                  color: theme.colorScheme.error,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: refreshData,
                child: const Text('Retry'),
              ),
            ],
          ),
        ),
      );
    }
    
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Organization Info Card
          Card(
            elevation: 2,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 36,
                    backgroundImage: NetworkImage(widget.organization.avatarUrl),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.organization.name ?? widget.organization.login,
                          style: theme.textTheme.titleLarge?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          '${widget.organization.publicRepos} public repositories',
                          style: theme.textTheme.bodyLarge,
                        ),
                        if (widget.organization.description != null)
                          Padding(
                            padding: const EdgeInsets.only(top: 8.0),
                            child: Text(
                              widget.organization.description!,
                              style: theme.textTheme.bodyMedium,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          
          const SizedBox(height: 16),
          
          // Stats Cards
          Row(
            children: [
              Expanded(
                child: _buildStatCard(
                  context,
                  'Total Repositories',
                  widget.organization.publicRepos.toString(),
                  Icons.folder,
                  theme.colorScheme.primary,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildStatCard(
                  context,
                  'Total Commits',
                  _totalCommits.toString(),
                  Icons.commit,
                  Colors.green,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildStatCard(
                  context,
                  'Pull Requests',
                  _totalPullRequests.toString(),
                  Icons.merge_type,
                  Colors.purple,
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 16),
          
          // Commit Activity Chart
          if (_commitActivity.isNotEmpty) ...[
            Card(
              elevation: 2,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Commit Activity',
                      style: theme.textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Weekly commit activity for ${_repositories[0].name}',
                      style: theme.textTheme.bodyMedium,
                    ),
                    const SizedBox(height: 16),
                    SizedBox(
                      height: 200,
                      child: _buildCommitActivityChart(context),
                    ),
                  ],
                ),
              ),
            ),
            
            const SizedBox(height: 16),
          ],
          
          // Top Contributors
          Card(
            elevation: 2,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Top Contributors',
                    style: theme.textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 16),
                  if (_topContributors.isEmpty)
                    const Center(
                      child: Text('No contributors found'),
                    )
                  else
                    ListView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: _topContributors.length > 5 ? 5 : _topContributors.length,
                      itemBuilder: (context, index) {
                        final contributor = _topContributors[index];
                        return ListTile(
                          leading: CircleAvatar(
                            backgroundImage: NetworkImage(contributor.avatarUrl),
                          ),
                          title: Text(contributor.name ?? contributor.login),
                          subtitle: Text('@${contributor.login}'),
                          trailing: Text(
                            '${contributor.contributions} commits',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: theme.colorScheme.primary,
                            ),
                          ),
                        );
                      },
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildStatCard(
    BuildContext context,
    String title,
    String value,
    IconData icon,
    Color color,
  ) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              color: color,
              size: 36,
            ),
            const SizedBox(height: 8),
            Text(
              value,
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 24,
                color: color,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              title,
              style: Theme.of(context).textTheme.bodyMedium,
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildCommitActivityChart(BuildContext context) {
    if (_commitActivity.isEmpty) {
      return const Center(child: Text('No commit activity data available'));
    }
    
    // Convert data for the chart
    final spots = <FlSpot>[];
    final labels = <String>[];
    
    for (int i = 0; i < _commitActivity.length; i++) {
      spots.add(FlSpot(i.toDouble(), _commitActivity[i].total.toDouble()));
      
      // Format date for label - Unix timestamp is in seconds
      final date = DateTime.fromMillisecondsSinceEpoch(_commitActivity[i].week * 1000);
      labels.add(DateFormat('MMM d').format(date));
    }
    
    return LineChart(
      LineChartData(
        gridData: FlGridData(
          show: true,
          drawVerticalLine: false,
          horizontalInterval: 20,
          getDrawingHorizontalLine: (value) {
            return FlLine(
              color: Colors.grey.withOpacity(0.2),
              strokeWidth: 1,
            );
          },
        ),
        titlesData: FlTitlesData(
          show: true,
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              getTitlesWidget: (value, meta) {
                final intValue = value.toInt();
             if (intValue >= 0 && intValue < labels.length && intValue % 2 == 0) {
                  return Padding(
                    padding: const EdgeInsets.only(top: 8.0),
                    child: Text(
                      labels[intValue],
                      style: const TextStyle(
                        color: Colors.grey,
                        fontWeight: FontWeight.bold,
                        fontSize: 10,
                      ),
                    ),
                  );
                }
                return const SizedBox();
              },
              reservedSize: 30,
            ),
          ),
          leftTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              getTitlesWidget: (value, meta) {
                return Text(
                  value.toInt().toString(),
                  style: const TextStyle(
                    color: Colors.grey,
                    fontWeight: FontWeight.bold,
                    fontSize: 10,
                  ),
                );
              },
              reservedSize: 30,
            ),
          ),
          rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
          topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
        ),
        borderData: FlBorderData(show: false),
        lineBarsData: [
          LineChartBarData(
            spots: spots,
            isCurved: true,
            color: Theme.of(context).colorScheme.primary,
            barWidth: 3,
            isStrokeCapRound: true,
            dotData: FlDotData(
              show: false,
            ),
            belowBarData: BarAreaData(
              show: true,
              color: Theme.of(context).colorScheme.primary.withOpacity(0.2),
            ),
          ),
        ],
      ),
    );
  }
}