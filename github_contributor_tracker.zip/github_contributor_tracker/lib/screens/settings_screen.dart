import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:github_contributor_tracker/providers/auth_provider.dart';
import 'package:github_contributor_tracker/providers/organization_provider.dart';
import 'package:github_contributor_tracker/screens/login_screen.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:url_launcher/url_launcher.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({Key? key}) : super(key: key);

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  PackageInfo? _packageInfo;
  bool _isDarkMode = false;
  
  @override
  void initState() {
    super.initState();
    _loadPackageInfo();
    
    // Get current theme mode
    final brightness = MediaQuery.of(context).platformBrightness;
    _isDarkMode = brightness == Brightness.dark;
  }
  
  Future<void> _loadPackageInfo() async {
    final info = await PackageInfo.fromPlatform();
    setState(() {
      _packageInfo = info;
    });
  }
  
  Future<void> _logout() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Logout'),
        content: const Text('Are you sure you want to logout?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('CANCEL'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('LOGOUT'),
          ),
        ],
      ),
    );
    
    if (confirmed == true) {
      final authProvider = Provider.of<AuthProvider>(context, listen: false);
      await authProvider.logout();
      
      if (mounted) {
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const LoginScreen()),
          (route) => false,
        );
      }
    }
  }
  
  Future<void> _clearRecentOrganizations() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Clear Recent Organizations'),
        content: const Text('Are you sure you want to clear your recent organizations history?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('CANCEL'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('CLEAR'),
          ),
        ],
      ),
    );
    
    if (confirmed == true) {
      final orgProvider = Provider.of<OrganizationProvider>(context, listen: false);
      orgProvider.clearRecentOrganizations();
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Recent organizations cleared')),
        );
      }
    }
  }
  
  void _openGitHubDocs() async {
    const url = 'https://docs.github.com/en/rest/metrics/statistics?apiVersion=2022-11-28';
    if (await canLaunch(url)) {
      await launch(url);
    }
  }
  
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final authProvider = Provider.of<AuthProvider>(context);
    
    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Account Section
          _buildSectionHeader(context, 'Account'),
          Card(
            child: Column(
              children: [
                if (authProvider.currentUser != null)
                  ListTile(
                    leading: CircleAvatar(
                      backgroundImage: NetworkImage(authProvider.currentUser!.avatarUrl),
                    ),
                    title: Text(
                      authProvider.currentUser!.name ?? authProvider.currentUser!.login,
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    subtitle: Text('@${authProvider.currentUser!.login}'),
                  ),
                ListTile(
                  leading: const Icon(Icons.logout),
                  title: const Text('Logout'),
                  onTap: _logout,
                ),
              ],
            ),
          ),
          
          const SizedBox(height: 24),
          
          // Preferences Section
          _buildSectionHeader(context, 'Preferences'),
          Card(
            child: Column(
              children: [
                SwitchListTile(
                  title: const Text('Dark Mode'),
                  subtitle: const Text('Use dark theme'),
                  value: _isDarkMode,
                  onChanged: (value) {
                    setState(() {
                      _isDarkMode = value;
                    });
                    // In a real app, you would save this preference and
                    // update the app's theme
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.delete_outline),
                  title: const Text('Clear Recent Organizations'),
                  onTap: _clearRecentOrganizations,
                ),
              ],
            ),
          ),
          
          const SizedBox(height: 24),
          
          // Help & Information
          _buildSectionHeader(context, 'Help & Information'),
          Card(
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.help_outline),
                  title: const Text('GitHub API Documentation'),
                  onTap: _openGitHubDocs,
                ),
                const Divider(),
                if (_packageInfo != null) ...[
                  ListTile(
                    title: const Text('App Version'),
                    trailing: Text('${_packageInfo!.version} (${_packageInfo!.buildNumber})'),
                  ),
                  ListTile(
                    title: const Text('Package Name'),
                    trailing: Text(_packageInfo!.packageName),
                  ),
                ],
              ],
            ),
          ),
          
          const SizedBox(height: 24),
          
          // About
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'About',
                    style: theme.textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'GitHub Contributor Tracker is a tool for tracking and analyzing contributor '
                    'activity across organization repositories. This tool helps project managers '
                    'monitor progress, evaluate team performance, and optimize development efforts.',
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'Developers',
                    style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 4),
                  const Text('Muhammad Usama Akbar'),
                  const Text('Muhammad Hamza'),
                  const Text('Muhammad Saad'),
                  const SizedBox(height: 16),
                  Text(
                    'Course',
                    style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 4),
                  const Text('Spring 2025 - COMP-370 (Software Construction and Development)'),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildSectionHeader(BuildContext context, String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
      child: Text(
        title,
        style: TextStyle(
          fontWeight: FontWeight.bold,
          color: Theme.of(context).colorScheme.primary,
        ),
      ),
    );
  }
}