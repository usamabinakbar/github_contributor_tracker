import 'package:flutter/material.dart';
import 'package:github_contributor_tracker/models/organization.dart';
import 'package:github_contributor_tracker/providers/auth_provider.dart';
import 'package:github_contributor_tracker/screens/tabs/overview_tab.dart';
import 'package:github_contributor_tracker/screens/tabs/repositories_tab.dart';
import 'package:github_contributor_tracker/screens/tabs/contributors_tab.dart';
import 'package:provider/provider.dart';

class DashboardScreen extends StatefulWidget {
  final Organization organization;

  const DashboardScreen({
    Key? key,
    required this.organization,
  }) : super(key: key);

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  
  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }
  
  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }
  
  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    final theme = Theme.of(context);
    
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.organization.name ?? widget.organization.login),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Overview'),
            Tab(text: 'Repositories'),
            Tab(text: 'Contributors'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          OverviewTab(
            organization: widget.organization,
            token: authProvider.token!,
          ),
          RepositoriesTab(
            organization: widget.organization, 
            token: authProvider.token!,
          ),
          ContributorsTab(
            organization: widget.organization,
            token: authProvider.token!,
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _refreshCurrentTab,
        tooltip: 'Refresh',
        child: const Icon(Icons.refresh),
      ),
    );
  }
  
  void _refreshCurrentTab() {
    final currentIndex = _tabController.index;
    
    switch (currentIndex) {
      case 0:
        final overviewTabState = (context.findAncestorStateOfType<OverviewTabState>());
        overviewTabState?.refreshData();
        break;
      case 1:
        final reposTabState = (context.findAncestorStateOfType<RepositoriesTabState>());
        reposTabState?.refreshData();
        break;
      case 2:
        final contributorsTabState = (context.findAncestorStateOfType<ContributorsTabState>());
        contributorsTabState?.refreshData();
        break;
    }
  }
}