import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:github_contributor_tracker/providers/auth_provider.dart';
import 'package:github_contributor_tracker/screens/login_screen.dart';
import 'package:github_contributor_tracker/screens/home_screen.dart';
import 'package:github_contributor_tracker/utils/theme.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    // Wait a bit and then check auth status to navigate
    Future.delayed(const Duration(seconds: 2), () {
      _checkAuthAndNavigate();
    });
  }
  
  void _checkAuthAndNavigate() {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    
    if (authProvider.isAuthenticated) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const HomeScreen()),
      );
    } else {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const LoginScreen()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.githubDark,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // App logo/icon
            Icon(
              Icons.bar_chart_rounded,
              size: 100,
              color: Colors.white,
            ),
            const SizedBox(height: 24),
            
            // App name
            Text(
              'GitHub Contributor Tracker',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 48),
            
            // Loading indicator
            CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
            ),
          ],
        ),
      ),
    );
  }
}