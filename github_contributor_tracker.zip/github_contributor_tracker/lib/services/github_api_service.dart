import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:github_contributor_tracker/models/organization.dart';
import 'package:github_contributor_tracker/models/repository.dart';
import 'package:github_contributor_tracker/models/contributor.dart';
import 'package:github_contributor_tracker/models/commit_stats.dart';
import 'package:github_contributor_tracker/models/code_frequency.dart';
import 'package:github_contributor_tracker/models/commit_activity.dart';
import 'package:github_contributor_tracker/utils/constants.dart';

class GitHubApiService {
  final String token;
  
  GitHubApiService(this.token);
  
  // Create headers with token
  Map<String, String> get _headers => {
    'Accept': 'application/vnd.github.v3+json',
    'Authorization': 'token $token',
  };
  
  // Generic GET request for GitHub API
  Future<dynamic> _get(String endpoint, {Map<String, String>? queryParams}) async {
    final uri = Uri.parse('${AppConstants.githubApiBaseUrl}$endpoint')
        .replace(queryParameters: queryParams);
    
    final response = await http.get(uri, headers: _headers);
    
    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else if (response.statusCode == 404) {
      throw Exception('Resource not found: $endpoint');
    } else if (response.statusCode == 403) {
      // Check if rate limited
      final rateLimitReset = response.headers['x-ratelimit-reset'];
      if (rateLimitReset != null) {
        final resetTime = DateTime.fromMillisecondsSinceEpoch(
            int.parse(rateLimitReset) * 1000);
        throw Exception('Rate limit exceeded. Reset at $resetTime');
      }
      throw Exception('API rate limit may have been exceeded');
    } else {
      throw Exception('API error: ${response.statusCode} - ${response.reasonPhrase}');
    }
  }
  
  // Get all organizations for the authenticated user
  Future<List<Organization>> getUserOrganizations() async {
    final data = await _get('/user/orgs');
    
    return (data as List)
        .map((org) => Organization.fromJson(org))
        .toList();
  }
  
  // Get specific organization details
  Future<Organization> getOrganization(String orgName) async {
    final data = await _get('/orgs/$orgName');
    return Organization.fromJson(data);
  }
  
  // Get repositories for an organization
  Future<List<Repository>> getOrganizationRepositories(
      String orgName, {int page = 1, int perPage = AppConstants.defaultPageSize}) async {
    final data = await _get('/orgs/$orgName/repos', 
        queryParams: {'page': page.toString(), 'per_page': perPage.toString()});
    
    return (data as List)
        .map((repo) => Repository.fromJson(repo))
        .toList();
  }
  
  // Get contributors for a repository
  Future<List<Contributor>> getRepositoryContributors(
      String owner, String repo, {int page = 1, int perPage = AppConstants.defaultPageSize}) async {
    final data = await _get('/repos/$owner/$repo/contributors', 
        queryParams: {'page': page.toString(), 'per_page': perPage.toString()});
    
    return (data as List)
        .map((contributor) => Contributor.fromJson(contributor))
        .toList();
  }
  
  // Get contributor statistics for a repository
  Future<List<CommitStatistics>> getContributorStats(String owner, String repo) async {
    try {
      final data = await _get('/repos/$owner/$repo/stats/contributors');
      
      return (data as List)
          .map((stats) => CommitStatistics.fromJson(stats))
          .toList();
    } catch (e) {
      print('Error getting contributor stats: $e');
      return [];
    }
  }
  
  // Get weekly code frequency for a repository
  Future<List<CodeFrequency>> getCodeFrequency(String owner, String repo) async {
    try {
      final data = await _get('/repos/$owner/$repo/stats/code_frequency');
      
      return (data as List)
          .map((week) => CodeFrequency.fromJson(week))
          .toList();
    } catch (e) {
      print('Error getting code frequency: $e');
      return [];
    }
  }
  
  // Get weekly commit activity for a repository
  Future<List<CommitActivity>> getCommitActivity(String owner, String repo) async {
    try {
      final data = await _get('/repos/$owner/$repo/stats/commit_activity');
      
      return (data as List)
          .map((week) => CommitActivity.fromJson(week))
          .toList();
    } catch (e) {
      print('Error getting commit activity: $e');
      return [];
    }
  }
  
  // Get all contributors across all repositories in an organization
  Future<Map<String, Contributor>> getAllOrganizationContributors(String orgName) async {
    final Map<String, Contributor> contributors = {};
    
    // Get all repositories
    List<Repository> allRepos = [];
    int page = 1;
    List<Repository> repoPage;
    
    do {
      repoPage = await getOrganizationRepositories(orgName, page: page);
      allRepos.addAll(repoPage);
      page++;
    } while (repoPage.isNotEmpty && allRepos.length < AppConstants.maxItemsToFetch);
    
    // Get contributors for each repository
    for (final repo in allRepos) {
      try {
        final repoContributors = await getRepositoryContributors(orgName, repo.name);
        
        for (final contributor in repoContributors) {
          if (contributors.containsKey(contributor.login)) {
            // Sum up contributions if contributor already exists
            final existing = contributors[contributor.login]!;
            contributors[contributor.login] = Contributor(
              login: existing.login,
              id: existing.id,
              avatarUrl: existing.avatarUrl,
              contributions: existing.contributions + contributor.contributions,
              name: existing.name,
            );
          } else {
            contributors[contributor.login] = contributor;
          }
        }
      } catch (e) {
        print('Error getting contributors for ${repo.name}: $e');
      }
    }
    
    return contributors;
  }
}